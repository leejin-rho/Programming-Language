int func(int x, int y)
{
}
int main()
{
	int c;
	int d=4;
	func(3,4);
	aa();
    aa();
	bb(3);
	cc(11,111,222);
}
