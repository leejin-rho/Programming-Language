#include <stdio.h>
#define MAX 987654321
int pem = 01;
int minusnum = -8;
int epm = 2; // epm = 2
/*
pp ppp
*/
int main(){
printf("%d",minusnum++);
int pp[3];
int* ppp = pp;
}
